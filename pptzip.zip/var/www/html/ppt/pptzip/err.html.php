<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ERROR!</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>

</head>

<body>
    <div class="wrapper">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
              <div class="page-header">
                <h2>ERROR!</h2>
		<h3><?php echo $error ?></h3>
              </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>





















<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"    
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>    
    <title>Error!</title>    
    <meta http-equiv="content-type"    
        content="text/html; charset=utf-8"/>    
  </head>
  <body>
    <p>
    </p>
  </body>
</html>
-->

